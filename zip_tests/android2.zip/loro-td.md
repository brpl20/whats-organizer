1. Listener 
2. Functions: 
    a) Google Distance
    b) Send Order to Listener
    c) Cobranca (IUGU) 
3. Front: Copiar do sistema do Gean
    
